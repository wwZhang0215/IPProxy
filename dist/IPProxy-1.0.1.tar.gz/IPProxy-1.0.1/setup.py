# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name='IPProxy',
    version='1.0.1',
    packages=[''],
    url='https://github.com/johnsonzww/IPProxy',
    license='',
    author='张文纬',
    author_email='z929527511@outlook.com',
    description='ip tool for proxy',
    requires=[
        'bs4',
        'requests',
    ]
)
